import React, { useState } from 'react';
import * as Yup from 'yup'; // Import Yup for validation
import "../RegistrationForm/RegistrationForm.css";
import { ProviderAdd } from '../../Services/Api';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

function RegistrationForm() {
  const navigate = useNavigate()
  const initialState = {
    shopName: '',
    password: '',
    name: '',
    phoneNo: '',
    emailId: '',
    category: 'menssaloon',
    shopEmail: '',
    address: '',
    area: '',
    city: '',
    state: '',
    postalCode: ''
  };

  const [formValue, setFormValue] = useState(initialState);
  const [file, setFile] = useState(null);
  const [fileUrl, setFileUrl] = useState('');
  const [errors, setErrors] = useState({}); // State to hold validation errors

  // Yup schema for validation
  const validationSchema = Yup.object().shape({
    shopName: Yup.string().required('Shop name is required'),
    password: Yup.string().required('Password is required'),
    name: Yup.string().required('Your name is required'),
    phoneNo: Yup.string()
    .matches(/^[0-9]{10}$/, 'Phone number must be exactly 10 digits')
    .required('Phone number is required'),
    emailId: Yup.string().email('Invalid email').required('Email is required'),
    category: Yup.string().required('Category is required'),
    shopEmail: Yup.string().email('Invalid email'),
    address: Yup.string().required('Street address is required'),
    city: Yup.string().required('City is required'),
    state: Yup.string().required('State is required'),
    postalCode: Yup.string().required('Postal code is required')
  });

  const toggleSubmit = (e) => {
    e.preventDefault();
    validationSchema.validate(formValue, { abortEarly: false })
      .then(() => {
        ProviderAdd(formValue)
          .then((res) => {
            console.log(res);
            setFormValue(initialState);
            toast.success(res.data.message)
            navigate('/');
          })
          .catch((err) => {
            console.log(err);
            alert('Error submitting form. Please try again.');
          });
      })
      .catch((validationErrors) => {
        const errors = {};
        validationErrors.inner.forEach(error => {
          errors[error.path] = error.message;
        });
        setErrors(errors);
      });
  };

  const toggleChange = (e) => {
    const { name, value } = e.target;
    setFormValue({
      ...formValue,
      [name]: value,
    });
  };


  return (
    <div className='container'>
      <div className='provLog'>PROVIDERS SIGNUP </div>
      <span>Home > Register PS</span>
      <form>
        <div className='d-flex flex-column'>
          <div className="row">
            <span className=' heading'>Registration form</span>
            <span className='fillEv'>Fill everything*</span>
          </div>

          <div className='d-flex flex-wrap formStarts'>
            <div className='input-pair'>
              <label className='inputLabel'>Shop name*</label>
              <input placeholder='Shop name' className='inputBox' name="shopName" value={formValue.shopName} onChange={toggleChange} />
              {errors.shopName && <p className="error">{errors.shopName}</p>}
            </div>
            <div className='input-pair'>
              <label className='inputLabel'>Your Name*</label>
              <input placeholder='Your Name' name="name" className='inputBox' value={formValue.name} onChange={toggleChange} />
              {errors.name && <p className="error">{errors.name}</p>}
            </div>
          </div>

          <div className='d-flex flex-wrap inputFields'>
            <div className='input-pair'>
              <label className='inputLabel'>Phone*</label>
              <input placeholder='Phone' name='phoneNo' className='inputBox' value={formValue.phoneNo} onChange={toggleChange} />
              {errors.phoneNo && <p className="error">{errors.phoneNo}</p>}
            </div>
            <div className='input-pair'>
              <label className='inputLabel'>Email ID*</label>
              <input placeholder='Email' className='inputBox' name='emailId' value={formValue.emailId} onChange={toggleChange} />
              {errors.emailId && <p className="error">{errors.emailId}</p>}
            </div>
          </div>

          <div className='d-flex flex-wrap inputFields'>
            <div className='input-pair'>
              <label className='inputLabel'>Category*</label>
              <select className='inputBox' name="category" value={formValue.category} onChange={toggleChange}>
                <option value="menssaloon">Mens Saloon</option>
                <option value="womensspa">Womens Spa</option>
                <option value="acservice">AC Service</option>
                <option value="painting">Painting</option>
                <option value="plumbing">Plumbing</option>
                <option value="electrical">Electrical</option>
                <option value="car">Car Wash</option>
                <option value="homeservices">Home Services</option>
              </select>
              {errors.category && <p className="error">{errors.category}</p>}
            </div>
            <div className='input-pair'>
              <label className='inputLabel'>Shop's Email ID</label>
              <input placeholder='Email' className='inputBox' name="shopEmail" value={formValue.shopEmail} onChange={toggleChange} />
              {errors.shopEmail && <p className="error">{errors.shopEmail}</p>}
            </div>
          </div>

          <div className='d-flex flex-wrap inputFields'>
            <div className='input-pair'>
              <label className='inputLabel'>Password*</label>
              <input placeholder='Password' className='inputBox' name="password" type="password" value={formValue.password} onChange={toggleChange} />
              {errors.password && <p className="error">{errors.password}</p>}
            </div>
          </div>

          <div className='d-flex flex-wrap inputFields'>
            <div className='input-pair'>
              <label className='inputLabel'>Street Address*</label>
              <input placeholder='Street Address' className='inputBox' name="address" value={formValue.address} onChange={toggleChange} />
              {errors.address && <p className="error">{errors.address}</p>}
            </div>
            <div className='input-pair'>
              <label className='inputLabel'>Area</label>
              <input placeholder='Area' className='inputBox' name="area" value={formValue.area} onChange={toggleChange} />
              {errors.area && <p className="error">{errors.area}</p>}
            </div>
          </div>

          <div className='d-flex flex-wrap inputFields'>
            <div className='input-pair'>
              <label className='inputLabel'>City*</label>
              <input placeholder='City' className='inputBox' value={formValue.city} name="city" onChange={toggleChange} />
              {errors.city && <p className="error">{errors.city}</p>}
            </div>
            <div className='input-pair'>
              <label className='inputLabel'>State*</label>
              <input placeholder='State' className='inputBox' value={formValue.state} name="state" onChange={toggleChange} />
              {errors.state && <p className="error">{errors.state}</p>}
            </div>
          </div>

          <div className='d-flex flex-wrap inputFields'>
            <div className='input-pair'>
              <label className='inputLabel'>Postal Code*</label>
              <input placeholder='Postal Code' className='inputBox' value={formValue.postalCode} name="postalCode" onChange={toggleChange} />
              {errors.postalCode && <p className="error">{errors.postalCode}</p>}
            </div>
          </div>

          <div>
            <button type='submit' className='btn' onClick={toggleSubmit}>Save</button>
            <button type='reset' className='btn'>Cancel</button>
          </div>
        </div>
      </form>
    </div>
  );
}

export default RegistrationForm;

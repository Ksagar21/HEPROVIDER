const host ="http://localhost:5000/";

export const LOGINUSER = host+"auth/login";
export const GETSHOPSBYCATEGORY =host+"api/getshops?category="
export const GETSERVICES = host+"api/getshopServices?shopEmail=";
export const ADDPROVIDERS =host+"auth/providerRegistration/";
export const ADDSERVICE=host+"api/provider/addService/";
export const UPDATESERVICE = host+"api/provider/updateService/";
export const GETBOOKINGS = host+"api/bookings";